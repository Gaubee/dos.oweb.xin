// 极简 PlayCanvas 游戏：旋转的彩色立方体 + 方向键控制旋转速度。
export function boot({ canvas, app, pc }) {
  app.scene.ambientLight = new pc.Color(0.2, 0.2, 0.2);

  // 相机
  const camera = new pc.Entity('camera');
  camera.addComponent('camera', {
    clearColor: new pc.Color(0.1, 0.1, 0.15),
    fov: 60,
  });
  camera.setLocalPosition(0, 0, 8);
  app.root.addChild(camera);

  // 光源
  const light = new pc.Entity('light');
  light.addComponent('light', { type: 'directional', color: new pc.Color(1, 1, 1), intensity: 1.2 });
  light.setEulerAngles(45, 30, 0);
  app.root.addChild(light);

  // 立方体（6 面不同颜色的 box）
  const box = new pc.Entity('box');
  const material = new pc.StandardMaterial();
  material.diffuse = new pc.Color(0.8, 0.3, 0.5);
  material.diffuseMap = makeRainbowTexture(pc, app);
  material.update();
  box.addComponent('render', { type: 'box', material });
  app.root.addChild(box);

  // 旋转速度（方向键控制）
  let speedX = 0.5;
  let speedY = 1.0;
  const onKey = (e) => {
    if (e.key === pc.KEY_LEFT || e.key === pc.KEY_A) speedY = Math.max(speedY - 0.3, 0);
    if (e.key === pc.KEY_RIGHT || e.key === pc.KEY_D) speedY += 0.3;
    if (e.key === pc.KEY_UP || e.key === pc.KEY_W) speedX = Math.max(speedX - 0.3, 0);
    if (e.key === pc.KEY_DOWN || e.key === pc.KEY_S) speedX += 0.3;
  };
  app.keyboard.on(pc.EVENT_KEYDOWN, onKey);

  // 每帧旋转
  app.on('update', (dt) => {
    box.rotate(speedX * dt * 30, speedY * dt * 30, 0);
  });

  // 清理函数
  return () => {
    app.keyboard.off(pc.EVENT_KEYDOWN, onKey);
  };
}

// 生成彩虹纹理（纯代码，无需资源文件）
function makeRainbowTexture(pc, app) {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  const grad = ctx.createLinearGradient(0, 0, size, size);
  grad.addColorStop(0, '#ff006e');
  grad.addColorStop(0.3, '#fb5607');
  grad.addColorStop(0.6, '#ffbe0b');
  grad.addColorStop(1, '#3a86ff');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);
  const texture = new pc.Texture(app.graphicsDevice, {
    width: size, height: size, format: pc.PIXELFORMAT_R8_G8_B8_A8,
  });
  texture.setSource(canvas);
  texture.addressU = pc.ADDRESS_CLAMP_TO_EDGE;
  texture.addressV = pc.ADDRESS_CLAMP_TO_EDGE;
  return texture;
}
